typedef struct {
  uint64_t amount;
} transfer;

#define CREATE_ACCOUNT 0
#define TRANSFER 2
